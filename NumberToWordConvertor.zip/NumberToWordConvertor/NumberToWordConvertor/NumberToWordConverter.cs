﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToWordConvertor
{
    public class NumberToWordConverter
    {
        private static string[] unitsPosition = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
        private static string[] tensPosition = new[] { "zero", "ten", "twenty ", "thirty ", "forty ", "fifty ", "sixty ", "seventy ", "eighty ", "ninety " };

        public static string NumberToWords(int number)
        {
            if (number == 0)
                return "zero";

            if (number < 0)
                return "minus " + NumberToWords(int.Parse(number.ToString().Substring(1)));

            StringBuilder words = new StringBuilder();

            if ((number / 1000000) > 0)
            {
                words.Append(NumberToWords(number / 1000000) + " million ");
                number %= 1000000;
            }

            if ((number / 1000) > 0)
            {
                words.Append(NumberToWords(number / 1000) + " thousand ");
                number %= 1000;
            }

            if ((number / 100) > 0)
            {
                words.Append(NumberToWords(number / 100) + " hundred ");
                number %= 100;
            }

            if (number > 0)
            {
                if (words.ToString() != "")
                    words.Append("and ");                

                if (number < 20)
                    words.Append(unitsPosition[number]);
                else
                {
                    words.Append(tensPosition[number / 10]);
                    if ((number % 10) > 0)
                        words.Append(unitsPosition[number % 10]);
                }
            }

            return words.ToString().Trim();
        }
    }
}
