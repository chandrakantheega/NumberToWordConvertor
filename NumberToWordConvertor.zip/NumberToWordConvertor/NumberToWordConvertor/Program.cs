﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToWordConvertor
{
    class Program
    {        
        static void Main(string[] args)
        {
            try
            {
                // Implemented the Number to Word convertor without considering the decimal numbers. Please do let me know, if at all we need number convertor for decimal numbers also.
                Console.WriteLine("Please enter a Number to convert to a Word");

                string numberStr = Console.ReadLine();

                int numbericNumber;

                bool isValid = int.TryParse(numberStr.Trim().Replace(",","").Replace(" ",""), out numbericNumber);

                if (!isValid)
                {
                    Console.WriteLine("Please enter valid Number.");
                }
                else
                {
                    Console.WriteLine("{0} = {1}", numberStr, NumberToWordConverter.NumberToWords(numbericNumber));
                }

                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
